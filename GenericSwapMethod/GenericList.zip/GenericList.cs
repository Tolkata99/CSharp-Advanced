﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GenericSwapMethod
{
    public class GenericList<T>
    {
        public List<T> Values { get; set; } = new List<T>();

        public GenericList(List<T> data)
        {
            this.Values = data;
        }

        public void Swap(int indexA,int indexB)
        {           
            T tmp = this.Values[indexA];
            this.Values[indexA] = this.Values[indexB];
            this.Values[indexB] = tmp;
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();

            foreach (T item in Values)
            {
                sb.AppendLine($"{item.GetType()}: {item.ToString()}");
            }

            return sb.ToString();
        }

    }
}
