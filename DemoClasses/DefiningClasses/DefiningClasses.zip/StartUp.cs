﻿using System;

namespace DefiningClasses
{
    public class StartUp
    {
        public static void Main(string[] args)
        {

            int n = int.Parse(Console.ReadLine());
            Family family = new Family();

            for (int i = 0; i < n; i++)
            {
                string[] tokens = Console.ReadLine().Split();
                string name = tokens[0];
                int age = int.Parse(tokens[1]);

                Person person = new Person(name, age);

                family.AddPeople(person);
            }
            

           Person oldestPerson = family.GetOldestMember();
            Console.WriteLine($"{oldestPerson.Name } {oldestPerson.Age}");
        }
    }
}
