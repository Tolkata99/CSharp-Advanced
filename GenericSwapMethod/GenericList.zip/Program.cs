﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace GenericSwapMethod
{
    public class Program
    {
        public static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            List<int> values = new List<int>();

            for (int i = 0; i < n; i++)
            {
                int words = int.Parse(Console.ReadLine());

                values.Add(words);

            }
            int[] indexes = Console.ReadLine()
                                   .Split()
                                   .Select(int.Parse)
                                   .ToArray();

            GenericList<int> list = new GenericList<int>(values);

            list.Swap(indexes[0], indexes[1]);

            Console.WriteLine(list.ToString()); ;
        }
    }
}
