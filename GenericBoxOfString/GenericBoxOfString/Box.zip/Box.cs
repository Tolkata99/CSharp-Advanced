﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GenericBoxOfString
{
    public class Box<T>
    {
        private T box;

        public Box(T box)
        {
            this.box = box;
        }

        public override string ToString()
        {
            return $"{box.GetType()}: {box}";
        }
    }
}
