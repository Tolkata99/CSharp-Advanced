﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BakeryOpenning
{
    public class Bakery
    {
        private List<Employee> Colections;

        public Bakery(string name, int capacity)
        {
            Employee = new List<Employee>();
            Name = name;
            Capacity = capacity;
            Count = this.Employee.Count;
        }

        public List<Employee> Employee { get; set; }

        public string Name { get; set; }

        public int Capacity { get; set; }

        public int Count { get; set; }


        public void Add(Employee employee)
        {
            this.Employee.Add(employee);
        }

        public bool Remove(string name)
        {
            var removedEmployee = this.Employee.FirstOrDefault(r => r.Name == name);

            if (removedEmployee != null)
            {
                this.Employee.Remove(removedEmployee);
                return true;
            }
            return false;
        }

        public Employee GetOldestEmployee()
        {
            int min = int.MinValue;
            Employee oldestEmployee = default;

            foreach (var empl in this.Employee)
            {
                if (empl.Age > min)
                {
                    oldestEmployee = empl;
                    min = empl.Age;
                }
            }

            return oldestEmployee;
        }

        public Employee GetEmployee(string name)
        {
            var firstName = this.Employee.FirstOrDefault(n => n.Name == name);

            return firstName;
        }

        public string Report()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append($"Employees working at Bakery {this.Name}");

            foreach (var employee in this.Employee)
            {
                sb.Append(employee.Name);
            }

            return sb.ToString();
        }
    }
}
