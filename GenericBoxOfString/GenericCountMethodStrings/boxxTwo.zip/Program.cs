﻿using System;
using System.Collections.Generic;

namespace GenericCountMethodStrings
{
    public class Program
    {
        public static void Main(string[] args)
        {
            
            int n = int.Parse(Console.ReadLine());
            List<string> list = new List<string>();
            boxxTwo<string> values = new boxxTwo<string>(list);


            for (int i = 0; i < n; i++)
            {
                string currWord = Console.ReadLine();

                values.AddList(currWord, list);

            }

            values = new boxxTwo<string>(list);
            string big = Console.ReadLine();

            Console.WriteLine(values.BigT(big));
        }
    }
}
