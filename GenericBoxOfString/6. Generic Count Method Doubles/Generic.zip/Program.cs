﻿using System;
using System.Collections.Generic;

namespace _6._Generic_Count_Method_Doubles
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            List<double> list = new List<double>();

            for (int i = 0; i < n; i++)
            {
                double number = double.Parse(Console.ReadLine());
                list.Add(number);

            }

            Generic<double> values = new Generic<double>(list);
            double value = double.Parse(Console.ReadLine());

            Console.WriteLine(values.Compare(values.Values,value));
        }
    }
}
