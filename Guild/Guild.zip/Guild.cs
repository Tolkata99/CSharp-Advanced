﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Guild
{
    public class Guild
    {
        public Guild(string name, int capacity)
        {
            guild = new List<Player>();
            Name = name;
            Capacity = capacity;
        }

        public List<Player> guild { get; set; }

        public string Name { get; set; }

        public int Capacity { get; set; }

        public int Count
        {
            get
            {
                return guild.Count;
            }
        }

        public string Report()
        {
            StringBuilder myString = new StringBuilder();
            myString.AppendLine($"Players in the guild: {this.Name}");
            foreach (var player in this.guild)
            {
                myString.AppendLine($"Player {player.Name}: {player.Class}");
                myString.AppendLine($"Rank: {player.Rank}");
                myString.AppendLine($"Description: {player.Description}");
            }
            return myString.ToString().TrimEnd();
        }




        public void AddPlayer(Player player)
        {
            if (guild.Count < Capacity)
            {
                guild.Add(player);
            }
        }

        public bool RemovePlayer(string name)
        {
            var playerRemoved = guild.FirstOrDefault(n => n.Name == name);

            if (playerRemoved != null)
            {
                guild.Remove(playerRemoved);
                return true;
            }

            return false;
        }

        public void PromotePlayer(string name)
        {
            Player player = guild.FirstOrDefault(n => n.Name == name && n.Rank != "Member");

            if (player != null)
            {
                player.Rank = "Member";
            }
        }

        public void DemotePlayer(string name)
        {
            Player player = guild.FirstOrDefault(n => n.Name == name && n.Rank != "Trial");

            if (player != null)
            {
                player.Rank = "Trial";
            }
        }

        public Player[] KickPlayersByClass(string classy)
        {

            List<Player> myListTemp = new List<Player>();
            foreach (var player in this.guild)
            {
                if (player.Class == classy)
                {
                    myListTemp.Add(player);
                }
            }
            Player[] myArrayToReturn = myListTemp.ToArray();

            this.guild = this.guild.Where(x => x.Class != classy).ToList();

            return myArrayToReturn;
        }


    }
}
