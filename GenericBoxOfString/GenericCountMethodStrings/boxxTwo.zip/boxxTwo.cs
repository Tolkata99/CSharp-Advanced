﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GenericCountMethodStrings
{
    public class boxxTwo<T> where T : IComparable
    {
        public List<T> Value { get; set; }

        public boxxTwo(List<T> item)
        {
            this.Value = item;
        }

        public void AddList(T item,List<T> list)
        {
            list.Add(item);
        }

        public int BigT(T bigWord)
        {
            int counter = 0;
            foreach(T value in this.Value)
            {
                
                if (bigWord.CompareTo(value) < 0)
                {
                    counter++;
                }
            }


            return counter;
        }

        public int CompareTo(object obj)
        {
            throw new NotImplementedException();
        }
    }
}
