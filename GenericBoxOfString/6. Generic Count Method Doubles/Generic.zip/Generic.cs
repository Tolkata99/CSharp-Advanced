﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _6._Generic_Count_Method_Doubles
{
    public class Generic<T> where T : IComparable
    {
        public List<T> Values { get; set; }

        public Generic(List<T> value)
        {
            Values = value;
        }

        public int Compare(List<T> values ,T value)
        {
            int counter = 0;
            foreach(T item in values)
            {
                if(value.CompareTo(item) < 0)
                {
                    counter++;
                }
            }
            return counter;
        }
    }
}
