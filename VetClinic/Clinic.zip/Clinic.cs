﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VetClinic
{
    public class Clinic
    {
        private List<Pet> Pet;

        public Clinic(int capacity)
        {
            Capacity = capacity;
            Pet = new List<Pet>();           
        }
      
        public int Capacity { get; set; }

        public int Count 
        {
            get
            {
                return CountMethod();
            }         
        }

        public void Add(Pet pet)
        {
            Pet.Add(pet);
        }

        public bool Remove(string name)
        {
            Pet removedEl = Pet.FirstOrDefault(p => p.Name == name);

            if(removedEl != null)
            {
                Pet.Remove(removedEl);
                return true;
            }
            return false;
        }

        public Pet GetPet(string name, string owner)
        {
            Pet getPet = Pet.FirstOrDefault(g => g.Name == name && g.Owner == owner);
            return getPet;
        }

        public Pet GetOldestPet()
        {
            int minValue = int.MinValue;
            Pet getOldestPet = default;

            foreach (var pet in Pet)
            {
                if(pet.Age > minValue)
                {
                    minValue = pet.Age;
                    getOldestPet = pet;
                }
            }
            return getOldestPet;
        }

        public string GetStatistics()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"The clinic has the following patients:");

            foreach (var pet in Pet)
            {
                sb.AppendLine($"Pet {pet.Name} with owner: {pet.Owner}");
            }

            return sb.ToString();
        }

        public int CountMethod()
        {
            int counter = 0;
            foreach (var count in Pet)
            {
                counter++;
            }

            return counter;
        }
    }
}
